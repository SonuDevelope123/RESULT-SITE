import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.sql.*;
public class LoginServlet extends HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		out.println("<html><body>");
		doGet(req,res);
		
	}
	public void doGet(HttpServletRequest req, HttpServletResponse res)
        throws ServletException,IOException {

        //resp.setContentType("text/html");
        //resp.getWriter().println("login.html");
		RequestDispatcher view = req.getRequestDispatcher("login.html");
        view.forward(req,res);

    }
	
}