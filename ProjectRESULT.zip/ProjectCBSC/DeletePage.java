import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.sql.*;
public class DeletePage extends HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		out.println("<html><body>");
		
		String s=req.getMethod();
		if(s.equals("GET"))
		{
			doGet(req,res);
		}
		
	}
	public void doGet(HttpServletRequest req, HttpServletResponse res)
        throws ServletException,IOException {

       res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		out.println("<html><body>");
		ServletContext ctx=getServletContext();
		String roll=req.getParameter("roll");
		String driver=ctx.getInitParameter("driver");
		String url=ctx.getInitParameter("url");
		String user=ctx.getInitParameter("user");
		String pass=ctx.getInitParameter("pass");
	   String rollno=req.getParameter("roll");
	   try{
		  Class.forName(driver);
			Connection con=DriverManager.getConnection(url,user,pass);
		   Statement st=con.createStatement();
	     ResultSet  checker=st.executeQuery("select * from Result_record  where rollno='"+rollno+"'");
          if(checker.next()!=false){
			  int x = st.executeUpdate("DELETE FROM Result_record WHERE rollno ="+rollno+" "); 
			 out.println("<h1>'"+x+"'</h1>");
		  }else{
			  out.println("<h1>else</h1>"); 
		  }
		    st.close();
	   }catch(Exception e){
			   
		  }
		 

			out.println("</body></html>");

    }
	
}