import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.sql.*;
public class InsertData extends HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		out.println("<html><body>");
		String s=req.getMethod();
		out.println(s);
		if(s.equals("POST"))
		{
			doPost(req,res);
		}
		if(s.equals("GET"))
		{
			doGet(req,res);
		}
	}
	public void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
			res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		ServletContext ctx=getServletContext();
		out.println("<html><body>");
		String name=req.getParameter("name");
		String roll=req.getParameter("pass");
		String math=req.getParameter("math");
		String chem=req.getParameter("chem");
		String phy=req.getParameter("phy");
		String hindi=req.getParameter("hindi");
		String eng=req.getParameter("eng");
		String driver=ctx.getInitParameter("driver");
		String url=ctx.getInitParameter("url");
		String user=ctx.getInitParameter("user");
		String pass=ctx.getInitParameter("pass");
		try{
Class.forName(driver);
			Connection con=DriverManager.getConnection(url,user,pass);
		  Statement st=con.createStatement();
			ResultSet  checker=st.executeQuery("select * from Result_record  where rollno='"+roll+"'");
		  if(checker.next()==false){
		  int x=st.executeUpdate("insert into Result_record values('"+roll+"','"+name+"','"+math+"','"+chem+"','"+phy+"','"+hindi+"','"+eng+"')");
		  if(x==1){
		out.println("<h1>Data Successfully Insert</h1>");
	       }
	    else{
		out.println("<h1><br>Sorry.....</h1>");
		
		out.println("</body></html>");
	      }
		  }else{
			  out.println("<html><body>");
			  out.println("<h1>Sorry this RollNumber is already exsist.........</h1>");
			    out.println("</body></html>");
		  }
		
	 st.close();
	}catch(Exception e)
	{
		System.out.println(e);
	}
	
			out.println("<h3><a href='login1'>back to home</a></h3>");

	out.println("</body></html>");				
		
	}
	public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		out.println("<html><body>");
		
	}
}