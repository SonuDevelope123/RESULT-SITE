import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.sql.*;
public class ShowAllData extends  HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		out.println("<html><body>");
		String s=req.getMethod();
		out.println(s);
		if(s.equals("POST"))
		{
			doPost(req,res);
		}
		if(s.equals("GET"))
		{
			doGet(req,res);
		}
	}
	public void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
			res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		ServletContext ctx=getServletContext();
		String roll=req.getParameter("roll");
		String driver=ctx.getInitParameter("driver");
		String url=ctx.getInitParameter("url");
		String user=ctx.getInitParameter("user");
		String pass=ctx.getInitParameter("pass");
		out.println("<html><body bgcolor='gray'>");	
		try{
	Class.forName(driver);
			Connection con=DriverManager.getConnection(url,user,pass);
		  Statement st=con.createStatement();
		 ResultSet  set=st.executeQuery("select * from Result_record ");
		  out.println("<h1 align='center'>Result By CodeSquadz<h1>");
	
		  ResultSetMetaData rsmd=set.getMetaData();
		  out.println("<table style='margin-bottom: 100' border=1 width=300 align='center' bgcolor='white' cellpadding=5 cellspacing=5>");
		  out.println("<tr>");
		  for(int i=1;i<=rsmd.getColumnCount();i++){
			  out.println("<th>"+rsmd.getColumnName(i)+"</th>");
		  }
		float total=0;
		float count=0;
		  while(set.next()){
			
			  out.println("<tr>");
			  out.println("<td>"+set.getString(1)+"</td>");
			  out.println("<td>"+set.getString(2)+"</td>");
			  out.println("<td>"+set.getString(3)+"</td>");
			  out.println("<td>"+set.getString(4)+"</td>");
			  out.println("<td>"+set.getString(5)+"</td>");
			  out.println("<td>"+set.getString(6)+"</td>");
			  out.println("<td>"+set.getString(7)+"</td>");
			  out.println("</tr>");
			  count=count+5;
			 total=set.getInt(3)+set.getInt(4)+set.getInt(5)+set.getInt(6)+set.getInt(7)+total;
		  }
		  
		  out.println("<th>Total Number of: '"+total+"'</th>");
		 float per=total/count;
		  out.println("<tr><td>...Percentage: "+per+"%</td></tr>");
		  if(per>=60){
			  out.println("<tr><td colspan=4>Ist Division <br> Congratulation You Pass...   A+</td></tr>");
		  }else if(per<60){
			  out.println("<tr><td colspan=4>2nd Division <br> Congratulation You Pass...   B+</td></tr>");
		  }
		  else if(per<33){
			   out.println("<tr><td colspan=4>Sorry You Fail <br> try to next Time.....</td></tr>");
		  }
		   st.close();
		}catch(Exception e){
			System.out.println(e);
		}
		
		out.println("</table>");
		out.println("<a href='Down' >download</a>");
		res.setHeader("Refresh","10;login.html");
		out.println("<h3><a href='login1'>back to home</a></h3>");
		
	out.println("</body></html>");
					
		
	}
	public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		out.println("<html><body>");
			out.println("User is invalid through get");
			out.println("<h1><a href='result.html'>back</br></h1>");
			out.println("<h1><a href='login.html'>Home</h1>");
			
		out.println("</body></html>");
		while(true){
			
		}
	}
}