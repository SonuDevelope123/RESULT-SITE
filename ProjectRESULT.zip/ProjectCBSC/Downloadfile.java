import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.sql.*;
import java.text.DateFormat;
public class Downloadfile extends HttpServlet
{
	PrintWriter out;
	public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		
	ServletContext ctx=getServletContext();
		String driver=ctx.getInitParameter("driver");
		String url=ctx.getInitParameter("url");
		String user=ctx.getInitParameter("user");
		String pass=ctx.getInitParameter("pass");
		try{
			res.setContentType("application/vnd.xlsx");
		out=res.getWriter();
			Class.forName(driver);
			Connection con=DriverManager.getConnection(url,user,pass);
			Statement st=con.createStatement();
			ResultSet set=st.executeQuery("select * from Result_record");
		  ResultSetMetaData rsmd=set.getMetaData();
			 for(int i=1;i<=rsmd.getColumnCount();i++){
			  out.print(rsmd.getColumnName(i)+"\t");
		  }
		  out.println("");
		  while(set.next()){
				out.print(set.getString(1)+"\t");
				out.print(set.getString(2)+"\t");
				out.print(set.getString(3)+"\t");
				out.print(set.getString(4)+"\t");
				out.print(set.getString(5)+"\t");
				out.print(set.getString(6)+"\t");
				out.println(set.getString(7)+"\t");
		  }
			
		}catch(Exception e){
			System.out.print(e);
		}
		
	}
}