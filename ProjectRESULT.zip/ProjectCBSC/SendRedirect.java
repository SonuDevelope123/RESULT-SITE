import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.sql.*;
public class SendRedirect extends HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		out.println("<html><body>");
		String user=req.getParameter("user");
		String pass=req.getParameter("pass");
		out.println(user);
	
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","root","root");
			Statement st=con.createStatement();
				
			ResultSet set=st.executeQuery("select * from Result_record4    where id='"+pass+"' and name='"+user+"'");
			
			if(set.next()){
				res.sendRedirect("login.html");
			}else
			{
				res.sendRedirect("start.html");
			}
			 st.close();
		}catch(Exception e)
		{
			//out.println(e);
		}
	
	}
}