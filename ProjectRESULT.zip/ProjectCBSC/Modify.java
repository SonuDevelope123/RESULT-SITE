import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.sql.*;
import java.util.Collections;
import java.util.Map;
import java.util.HashMap;
public class Modify extends HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		out.println("<html><body>");
		String s=req.getMethod();
		
		if(s.equals("POST"))
		{
			doPost(req,res);
		}
		if(s.equals("GET"))
		{
			doGet(req,res);
		}
	}
	public void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
			res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		out.println("<html><body>");
	   String rollno=req.getParameter("roll");
		String math=req.getParameter("math");
		String chem=req.getParameter("chem");
		String phy=req.getParameter("phy");
		String hindi=req.getParameter("hindi");
		String eng=req.getParameter("eng");
		ServletContext ctx=getServletContext();
		String roll=req.getParameter("roll");
		String driver=ctx.getInitParameter("driver");
		String url=ctx.getInitParameter("url");
		String user=ctx.getInitParameter("user");
		String pass=ctx.getInitParameter("pass");
		HashMap<String,String> al=new HashMap<String,String>();
	
		al.put("math",math);
		al.put("chem",chem);
			al.put("phy",phy);
		al.put("hindi",hindi);
		al.put("eng",eng);
		
		try{
	Class.forName(driver);
			Connection con=DriverManager.getConnection(url,user,pass);
		  Statement st=con.createStatement();

		 int count=al.size();
		
		   for(Map.Entry<String,String> entry:al.entrySet()){
			   if(entry.getValue().equals("null")||entry.getValue().equals("0"))
			   {
				   
			   }else{
				 String field=entry.getKey();
				   String value=entry.getValue(); 
				  
				st.executeUpdate("update  result_record set "+field+"="+value+" where rollno='"+rollno+"'"); 
			   } 

		   }
		    st.close();
	     
	}catch(Exception e)
	{
		System.out.println(e);
	}
	
			out.println("<h3><a href='login1'>back to home</a></h3>");

	out.println("</body></html>");				
		
	}
	public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		out.println("<html><body>");
		
	}
}